<?php

require_once('../../../../wp-load.php');


$email = $_REQUEST['mail'];
$name = $_REQUEST['name'];
$last_name = $_REQUEST['last_name'];
$random_password = wp_generate_password( 12 );

$user = get_user_by( 'email', $email );
    if ( !$user ) {
        $user_id = wp_create_user( $email, $random_password, $email );
        if ( is_wp_error( $user_id ) ) {
            $data['error'] = true;
            $data['error_desc'] = $user_id->get_error_message();
        } else {
            $data['succes'] = true;
            $data['succes_desc'] = 'user_create';
        }
    } else {
        $data['error'] = true;
        $data['error_desc'] = 'email_exist';
    }

$data['req'] = $_REQUEST;

header('Content-Type: application/json');
echo(json_encode ($data));